import java.awt.Point;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public class DiningCryptographers extends Protocol {
//private int [][] coins;
	private HashMap<Point,Integer> coins;
private int [] output;

public DiningCryptographers(int[][] network_array,int c){
	super(network_array, c);
	int size=network_array.length;
	this.networkgraph=network_array;
	//this.coins=new int[size][size];
	this.coins= new HashMap<Point,Integer>();
	this.output=new int[size];
	this.corrupted_users=c;
}

private void initialize_coins(){
	int size=this.networkgraph.length;
	Random sc=new Random();
	int current_coin;
for(int i=0;i<size;i++){
	for(int j=0;j<size;j++){
		if(i<j){
			
			if(this.networkgraph[i][j]==1){
				//System.out.println(i+" "+j);
				if(this.networkgraph[i][j]==1){
					current_coin=sc.nextInt(2);
					this.coins.put(new Point(i,j), current_coin);}
			}
		}
	}
	
	
}
	
int x,y,value;
for (Map.Entry<Point, Integer> entry : this.coins.entrySet()) {
	x=(entry.getKey()).x;
	y=(entry.getKey()).y;
	value=(entry.getValue()).intValue();
    System.out.println("("+x+","+y+"): "+value);
}	
	
}

private void initialize_output(int k){
	int x,y,value;
	int msg=1;
	for(int i=0;i<this.output.length;i++){
		for (Map.Entry<Point, Integer> entry : this.coins.entrySet()) {
			x=(entry.getKey()).x;
			y=(entry.getKey()).y;
			if(x==i || y==i){
				value=(entry.getValue()).intValue();
				this.output[i]=this.add(this.output[i],value);
				
			}
		    //System.out.println("("+x+","+y+"): "+value);
		}	
			
		}
	System.out.println("sender is "+ k);
	this.output[k]=this.add(this.output[k],msg);
	for(int i=0;i<this.output.length;i++){
		System.out.println("output "+i+" is "+output[i]);
	}
	}
	
	
public void clear(){
	this.output=new int[this.output.length];
	this.coins.clear();
}

public int add(int a,int b){
	int c=0;
	if((a==1 || a==0) && (b==0||b==1)){
		c=a+b;
		if(c==2){
			c=0;
		}
	}
	else{
		c=-1;
	}
	return c;
}
//write output and coins from corrupted users to file
public void export_info(){
	Point p=new Point();
	ArrayList<Integer> known_coins=new ArrayList<Integer>();
	int k=this.networkgraph.length-this.corrupted_users;
	for(int i=k;i<this.networkgraph.length;i++){
		for(int j=0;j<this.networkgraph.length;j++){
			if(this.networkgraph[i][j]==1){
				if(i>j){
					p.x=j;
					p.y=i;
				}
				else{
					p.x=i;
					p.y=j;
				}
				System.out.println("("+p.x+","+p.y+") "+this.coins.get(p));
				known_coins.add(this.coins.get(p));
			}
		}
	}
	
	
	
	
	String filename=dir+"adversaryinfo.txt";
	//
	this.output_file=filename;
	File file = new File(filename);
	boolean exist=false;
		if(file.exists()){
			
			exist=true;
		}
	
	
	
		 try {
			 BufferedWriter writer;
			 if(exist && this.count>0){
				 writer = new BufferedWriter(new FileWriter(filename,exist));
				}else{
					 writer = new BufferedWriter(new FileWriter(filename));
				}
				for(int i=0;i<this.output.length;i++){
					writer.write(String.valueOf(this.output[i])+" ");
		 
		 }
		 for(int i=0;i<known_coins.size();i++)	{
			 writer.write((known_coins.get(i)).toString()+" ");
		 }
		 writer.newLine();
		 writer.close();
		 }
		 catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}





public void execute(int k){
	
	this.initialize_coins();	
	this.initialize_output(k);
	this.export_info();
	this.count++;
	
	
	
	
	}


}
