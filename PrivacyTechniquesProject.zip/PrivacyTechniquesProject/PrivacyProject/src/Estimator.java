import java.util.ArrayList;


public class Estimator {
	private int [] real_senders;
	private ArrayList<Integer> estimated_senders;
	public Estimator(int [] senders,ArrayList<Integer> estimated_senders ){
		this.real_senders=senders;
		this.estimated_senders=estimated_senders;
		
		
		
	}
	
	public double calculate_success(){
		double sum=0.0;
		for(int i=0;i<this.real_senders.length;i++){
			System.out.println("s0:"+this.real_senders[i]+" e0:"+this.estimated_senders.get(i));
			if(this.real_senders[i]==this.estimated_senders.get(i)){
				sum=sum+1;
			}
		}
		sum=sum/this.real_senders.length;
		return sum;
	}
	
	
	
	
	
	
}
