
public class Attack {

	public static void main(String[] args) {
		ProtocolType protocol;
		String protocol_name=args[0].toLowerCase();
		//String protocol_name="crowds";
		final String dir = (System.getProperty("user.dir")+"/files/");
		//final String dir = (System.getProperty("user.dir")+"\\src\\files\\");//.replace("\\", "//");
		//final String dir1 = System.getProperty("user.dir")+"\\files\\";
		//String protocol_name="crowds";
		//String file="C://Users/Alexandros_Fotios//Documents//New folder//PrivacyProject//src//files//graphfile.txt";
		//String filex="C://Users/Alexandros_Fotios//Documents//New folder//PrivacyProject//src//files//priorfile.txt";
		//String filey="C://Users/Alexandros_Fotios//Documents//New folder//PrivacyProject//src//files//adversaryinfo.txt";
		//String file=dir+"graph-4-complete";
		String file=dir+args[1];
		//String filex=dir+"prior-3-uniform";
		String filex=dir+args[3];
		//String filey=dir+"adversaryinfo.txt";
		//String filey=dir+"adversaryinfo.txt";
		String filey=dir+args[4];

		NetworkGraph networkgraph_creater=new NetworkGraph(file);
		
		//NetworkGraph networkgraph_creater=new NetworkGraph(dir1+args[1],user_number);
		networkgraph_creater.read();
		System.out.println("Attack starting...");
		System.out.println("System has "+networkgraph_creater.network_array.length+" users.");
		int no_corrupted_users = 0;
		try{
			 no_corrupted_users=Integer.parseInt(args[2]);
			//no_corrupted_users=Integer.parseInt("1");
			System.out.println("System has "+no_corrupted_users+" corrupted users.");
		}
		catch(NumberFormatException e){
			e.printStackTrace();
		}
		//PriorKnowledge initial_adversary_knowledge=new PriorKnowledge(filex, networkgraph_creater.network_array.length);
		PriorKnowledge initial_adversary_knowledge=new PriorKnowledge(filex);
		int no_honest_users=networkgraph_creater.network_array.length-no_corrupted_users;
		initial_adversary_knowledge.honest_user_no=no_honest_users;
		//PriorKnowledge initial_adversary_knowledge=new PriorKnowledge(dir1+args[3], networkgraph_creater.network_array.length);
		initial_adversary_knowledge.read();
		/*float count=0;
		for(int i=0;i<networkgraph_creater.network_array.length;i++){
			System.out.println(i+"\t"+initial_adversary_knowledge.prior_file[i]);
			count+=initial_adversary_knowledge.prior_file[i];
		}
		System.out.println(count);*/
		
		Attacker adversary=new Attacker(filey,networkgraph_creater.network_array,initial_adversary_knowledge.prior_file,no_corrupted_users);
		int m;
		//Attacker adversary=new Attacker(dir1+args[4],networkgraph_creater.network_array,initial_adversary_knowledge.prior_file,no_corrupted_users);;
		int execution_number=adversary.get_ex_number();
		//System.out.println(execution_number);
		
		switch(protocol_name){
		case "dc":
			System.out.println("System use dc protocol.");
			protocol=ProtocolType.dc;
			
			for(int k=0;k<execution_number;k++){
				System.out.println("Attack "+k);
				m=adversary.get_max_prob();
				adversary.dcattack(k,m);
			
			}
			break;
		case "crowds":
			System.out.println("System use crowds protocol.");
			protocol=ProtocolType.crowds;
			for(int k=0;k<execution_number;k++){
				System.out.println("Attack "+k);
				System.out.println("exno:"+k);
				m=adversary.get_max_prob();
				adversary.crowds_attack(k, m);
			}
		
			
			
			
			break;
		default:
			System.out.println("System use unknown protocol.");
			return;
		
		}
		
		
		for(int i=0;i< networkgraph_creater.network_array.length;i++){
			for(int j=0;j<networkgraph_creater.network_array[0].length;j++){
				System.out.print(networkgraph_creater.network_array[i][j]+" ");
			}
			System.out.println("");
		}
		
		
		
		
		
		
		

	}

}
