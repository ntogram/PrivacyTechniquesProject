import java.io.File;


public class Simulation {
	public static void main(String[] args) {
		
		
		
		final String dir = (System.getProperty("user.dir")+"/files/");
		int execution_number=10000;
		//final String dir = (System.getProperty("user.dir")+"\\src\\files\\");//.replace("\\", "//");
		//final String dir1 = System.getProperty("user.dir")+"\\files\\";
	    // System.out.println("current dir = " + dir);
		//String file="C://Users/Alexandros_Fotios//Documents//New folder//PrivacyProject//src//files//graphfile.txt";
		//String filex="C://Users/Alexandros_Fotios//Documents//New folder//PrivacyProject//src//files//userfile.txt";
		//String file=dir+"graph-4-complete";
		String file=dir+args[1];
		String filex=dir+args[3];
		//String filex=dir+"userfile.txt";
		//String filex=dir+"userfile.txt";
		NetworkGraph networkgraph_creater=new NetworkGraph(file);
		//NetworkGraph networkgraph_creater=new NetworkGraph(dir1+args[1],user_number);
		networkgraph_creater.read();
		System.out.println("Simulation starting...");
		System.out.println("System has "+networkgraph_creater.network_array.length+" users.");
		ProtocolType protocol;
		String protocol_name=args[0].toLowerCase();
		//String protocol_name="crowds";
		//String protocol_name="dc";
		int no_corrupted_users=0;
		try{
			 no_corrupted_users=Integer.parseInt(args[2]);
			//no_corrupted_users=Integer.parseInt("1");
			System.out.println("System has "+no_corrupted_users+" corrupted users.");
		}
		catch(NumberFormatException e){
			e.printStackTrace();
		}
		
		
		User_execution userfile=new User_execution(filex, networkgraph_creater.network_array.length, execution_number);
		//User_execution userfile=new User_execution(dir1+args[3], networkgraph_creater.network_array.length, execution_number);
		userfile.read();
		System.out.println("number of execution: "+userfile.users_file.length);
		switch(protocol_name){
		case "dc":
			System.out.println("System use dc protocol.");
			protocol=ProtocolType.dc;
			DiningCryptographers d=new DiningCryptographers(networkgraph_creater.network_array,no_corrupted_users);
			for(int k=0;k<execution_number;k++){
				//d.execute(0);
			d.execute(userfile.users_file[k]);
			d.clear();
			}
			break;
		case "crowds":
			System.out.println("System use crowds protocol.");
			protocol=ProtocolType.crowds;
			Crowds c=new Crowds(networkgraph_creater.network_array,no_corrupted_users);
			for(int k=0;k<execution_number;k++){
				//c.execute(0);
				c.execute(userfile.users_file[k]);
				c.clear();
				}
			
			
			
			
			break;
		default:
			System.out.println("System use unknown protocol.");
			return;
		
		}
		//*/
		for(int i=0;i< networkgraph_creater.network_array.length;i++){
			for(int j=0;j<networkgraph_creater.network_array[0].length;j++){
				System.out.print(networkgraph_creater.network_array[i][j]+" ");
			}
			System.out.println("");
		}
		/*
		for(int i=0;i<userfile.users_file.length;i++){
			System.out.println(userfile.users_file[i]);
		}*/
		
		//System.out.println("adv: "+no_corrupted_users);
		
		

	}

}
