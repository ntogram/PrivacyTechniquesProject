
public abstract class Protocol {
	protected  int [][] networkgraph;
	protected int corrupted_users;
	protected String output_file;
	public  int count=0;
	final static String dir = (System.getProperty("user.dir")+"/files/");
	public Protocol(int[][] network_array,int c){
		this.networkgraph=network_array;
		this.corrupted_users=c;
	}
	abstract void clear();
	abstract void export_info();
	 abstract void execute(int k);
	
	
}
