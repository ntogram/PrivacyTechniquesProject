import java.awt.Point;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;

import org.apache.commons.math3.distribution.EnumeratedIntegerDistribution;



public class Crowds extends Protocol {
private ArrayList<Integer> path_user;
 private int sender;
 private final double  pf=0.75;

private  HashMap<Integer,ArrayList<Integer>> output;
	public Crowds(int[][] network_array, int c) {
		super(network_array, c);
		this.path_user=new ArrayList<Integer>();
		this.output=new HashMap<Integer,ArrayList<Integer>> ();
	}

	@Override
	void clear() {
		// TODO Auto-generated method stub
		this.path_user.clear();
		this.output.clear();
		this.sender=0;
	}

	@Override
	void export_info() {
		ArrayList<ArrayList<Integer>> nodes_sequences=new  ArrayList<ArrayList<Integer>>();
		ArrayList<Integer> current=new ArrayList<Integer>();
		int x=-1;
		//Point p=new Point();//x->represents previous node of corrupted node  y->next node of corrupted node
		int k=this.networkgraph.length-this.corrupted_users;
		int prev=0;
		int next=0;
		
			for(int j=k;j<this.networkgraph.length;j++){
				for(int i=0;i<this.path_user.size();i++){
					if(this.path_user.get(i)==j){
						//System.out.println("cor::"+j);
						prev=i-1;
						next=i+1;
						if(prev>=0){
							x=this.path_user.get(prev);
						}
						else{
							x=-1;
						}
						
						
							current.add(x);
							//System.out.println("("+p.x+","+p.y+")");
							//System.out.println(current.get(current.size()-1));
							
					
					
					
				}
		}
				//System.out.println("l1:"+nodes_sequences.size());
				if(current.size()>0){
				nodes_sequences.add(current);
				this.output.put(new Integer(j), nodes_sequences.get(nodes_sequences.size()-1));}
				//System.out.println("l2:"+(this.output.get(new Integer(j)).size()));
				
				
				
				
				current=new ArrayList<Integer>();
				x=-1;
				//System.out.println("l3:"+(this.output.get(new Integer(j)).size()));
		
			}
		
		System.out.println("------");
		int key;
		current.add(this.path_user.get(this.path_user.size()-2));
		this.output.put(this.path_user.get(this.path_user.size()-1),current);
	/*	for (Entry<Integer, ArrayList<Integer>> entry : this.output.entrySet()) {
			
			
			key=(entry.getKey()).intValue();
			
			
			System.out.println("corrupted node:"+key+":");
			current=entry.getValue();
		
				for(int i=0;i<current.size();i++){
					x=current.get(i);
					System.out.print(x);
					if(i!=current.size()-1)
						System.out.print("|");
				
			}
			
				System.out.println("");
				
		}	
		*/
		
		/*	for(int i=0;i<nodes_sequences.size();i++){
				for(int j=0;j<(nodes_sequences.get(i)).size();j++){
					System.out.println("("+(((nodes_sequences.get(i))).get(j)).x+","+(((nodes_sequences.get(i))).get(j)).y+")");
					
				}
			}*/
		
		String filename=dir+"adversaryinfo.txt";
		//
		this.output_file=filename;
		File file = new File(filename);
		
		boolean exist=false;
			if(file.exists()){
				
				exist=true;
			}

			 try {
				 BufferedWriter writer;
				 if(exist && this.count>0){
					 writer = new BufferedWriter(new FileWriter(filename,exist));
					}else{
						 writer = new BufferedWriter(new FileWriter(filename));
					}
				 int a=1;
				 for (Entry<Integer, ArrayList<Integer>> entry : this.output.entrySet()) {
						
						
						key=(entry.getKey()).intValue();
						writer.write(String.valueOf(key)+":");
						
						System.out.println("corrupted node:"+key+":");
						current=entry.getValue();
					
							for(int i=0;i<current.size();i++){
								x=current.get(i);
								writer.write(String.valueOf(x));
								System.out.print(x);
								if(a!=this.output.size()){
										if(i!=current.size()-1){
											writer.write(",");
											System.out.print(",");}}
								else{
									if(i!=current.size()-1){
										writer.write(",");
										System.out.print(",");}
								}
								
								
							
						}
							writer.write(" ");
							System.out.print(" ");
							a++;
					}	
				 
				 writer.newLine();
				 writer.close();
				 System.out.println("");
				 
				 
				 
				 
				 
				 
				 
			 }
			 catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 
			 //*/
		
		
		
			
		
			
			
			
			
			
			
	}
//get list of adjacents nodes of graph
	private ArrayList<Integer> getadjacents(int k){
		
		ArrayList<Integer> adjacents=new ArrayList<Integer>();
		adjacents.add(new Integer(k));
		for(int i=0;i<this.networkgraph.length;i++){
			if(this.networkgraph[k][i]==1){
				adjacents.add(i);
				//System.out.println("adj: "+i);
			}
		}
		
		return adjacents;
	}
	
	// select forward or deliver with  fi=0.75
	private Action selectaction(){
		int[] numsToGenerate           = new int[]    { 0,1  };
		double[] discreteProbabilities = new double[] { pf,1-pf };

		EnumeratedIntegerDistribution distribution = 
		    new EnumeratedIntegerDistribution(numsToGenerate, discreteProbabilities);

		
		int sample = distribution.sample();
		System.out.println("out:"+sample);
		if(sample==0){
			return Action.forward;
		}
		else{
			return Action.deliver;
		}
		
		
		
		
		
		
	}
	
	
	@Override
	void execute(int k) {
		System.out.println("exno:"+this.count);
		this.sender=k;
		System.out.println("sender is "+ this.sender);
		ArrayList<Integer> next_nodes=this.getadjacents(this.sender);
		Random rn=new Random();
		int id=rn.nextInt(next_nodes.size());
		int current_node=next_nodes.get(id);
		this.path_user.add(sender);
		this.path_user.add(current_node);
		System.out.println("selected: "+current_node);
		Action next_action=this.selectaction();
		int count=0;
		
		while(next_action!=Action.deliver) {
			
			next_nodes=this.getadjacents(current_node);
			id=rn.nextInt(next_nodes.size());
			current_node=next_nodes.get(id);
			this.path_user.add(current_node);
			System.out.println("selected: "+current_node);
			System.out.println(count+")forward");
			next_action=this.selectaction();
			count++;
		}
		System.out.println(count+")deliver");
		//server as node with id -1
		this.path_user.add(-1);
		System.out.print("Path:");
		
		System.out.println(this.path_user);
		this.export_info();
		this.count++;
	}
	
	
	
	
	
}
