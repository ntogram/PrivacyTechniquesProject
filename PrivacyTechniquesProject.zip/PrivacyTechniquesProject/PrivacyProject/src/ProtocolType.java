
public enum ProtocolType {
dc,
crowds
}
