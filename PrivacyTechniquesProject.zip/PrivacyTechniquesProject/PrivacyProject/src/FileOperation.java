import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;









public abstract class FileOperation {
	protected  int  user_no;
	protected String filename;
	

	abstract public  void create();
	
	
	abstract public  void read();
	
	
	public int get_no_lines(){
		int count=0;
		try {
			FileReader fr = new FileReader(this.filename);
			BufferedReader br = new BufferedReader(fr);
			String sCurrentLine;
		

			try {
				
				while ((sCurrentLine = br.readLine()) != null) {
					
					
					count++;
					
				}
				
				
		}
			catch (IOException e) {

				e.printStackTrace();

			}
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		
		
		
		return count;
	}
	
	public  FileOperation( String filename,int userno){
		this.filename=filename;
		this.user_no=userno;
		this.create();
		
		
		
	}
	public FileOperation(String filename){
		this.filename=filename;
		this.user_no=this.get_no_lines();
		
		
		
		
		
		
		
	}


	public FileOperation() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
