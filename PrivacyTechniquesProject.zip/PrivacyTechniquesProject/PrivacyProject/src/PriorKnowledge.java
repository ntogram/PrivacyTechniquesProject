import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.lang.Math;



public class PriorKnowledge extends FileOperation   {
	public double [] prior_file;
	public int honest_user_no;
	public PriorKnowledge(String filename) {
		super(filename);
		// TODO Auto-generated constructor stub
	}
	
	public PriorKnowledge(String filename, int userno) {
		super(filename, userno);
		
	}
	@Override
	public void create() {
		
		Random randomno = new Random();
		double []possibilities=new double [this.user_no];
		double k=0;
		double sum=1;
		double min_val=0.5/(double)(this.user_no);
		double max_val=1.5/(double)(this.user_no);
		for(int i=0;i<this.user_no-1;i++){
			k=randomno.nextDouble();
			while(k>sum|| k<min_val || k>max_val){
			k=randomno.nextDouble();
			
			//System.out.println(i+"\t"+k);
			}
			possibilities[i]=k;
			sum=sum-k;
		}
		possibilities[this.user_no-1]=sum;
		for (int i=0; i<possibilities.length; i++) {
		    int randomPosition = randomno.nextInt(possibilities.length);
		    double temp = possibilities[i];
		    possibilities[i] = possibilities[randomPosition];
		    possibilities[randomPosition] = temp;
		}
		
		

		double count=0;
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(this.filename));
			Random re=new Random();
			int sender_id;
			for(int i=0;i<this.user_no;i++){
				System.out.println(i+"\t"+possibilities[i]);
				count+=possibilities[i];
				writer.write(String.valueOf(possibilities[i]));
				if(i!=this.user_no-1){
					//System.out.print(" ");
					writer.write(" ");}
				
				
			}
				
			//System.out.println("count:"+count);
			
		
			writer.close();
		
		
		 } catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
		
		
		
		
		
		//System.out.println(count);
		// TODO Auto-generated method stub
		
	}

	
	
	
	@Override
	public void read() {
		try {
			FileReader fr = new FileReader(this.filename);
			BufferedReader br = new BufferedReader(fr);
			String sCurrentLine;
			String[] line=new String[this.honest_user_no];
			int count=0;
			try {
				while ((sCurrentLine = br.readLine()) != null) {
					try{
						line=sCurrentLine.split(" ");
						//System.out.println(line.length);
						//this.user_no=line.length;
						this.prior_file=new double [this.honest_user_no];
						for(int i=0;i<this.honest_user_no;i++){
							this.prior_file[i]=Double.parseDouble(line[i]);
							
							
						}
					}
					catch(NumberFormatException e){
						e.printStackTrace();
					}
					
					count++;
				}}
				catch (IOException e) {

					e.printStackTrace();

				}
		}
				
			catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
}
		
	
	

}
