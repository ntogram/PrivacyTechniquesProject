import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

import org.apache.commons.math3.distribution.EnumeratedIntegerDistribution;


public class User_execution extends FileOperation {
	private int execution_no;
	public int [] users_file;
	
	
	public User_execution(String filename, int userno,int exno) {
		super(filename, userno);
		this.execution_no=exno;
		this.create();
	}
	
	public User_execution(int userno,int exno){
		super();
		this.user_no=userno;
		this.execution_no=exno;
	}

	@Override
	public void create() {
		
		 try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(this.filename));
			Random re=new Random();
			int sender_id;
			for(int i=0;i<this.execution_no;i++){
				sender_id=re.nextInt(this.user_no);
				
				writer.write(String.valueOf(sender_id));
				writer.newLine();
			}
		
			writer.close();
		
		
		 } catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
		
		
	}
	
	public  void  create(double [] probabilities) {
		int [] senders=new int[probabilities.length];
		for (int i=0;i<senders.length;i++){
			senders[i]=i;
		}
		EnumeratedIntegerDistribution distribution = 
		new EnumeratedIntegerDistribution(senders, probabilities);
		int [] samples=new int[this.execution_no];
		for(int i=0;i<this.execution_no;i++){
			samples[i]=distribution.sample();
		}
		/*double [] pr=new double[this.user_no];
		for(int i=0;i<samples.length;i++){
			for(int j=0;j<this.user_no;j++){
				if(samples[i]==j){
					pr[j]++;
					break;
				}
			}
		}
		for(int j=0;j<this.user_no;j++){
			pr[j]=pr[j]/samples.length;
			System.out.println(j+")"+pr[j]);
		}*/
		this.users_file=samples;
		
		
		
		
		
		
		
	}

	@Override
	public void read() {
		try {
			FileReader fr = new FileReader(this.filename);
			BufferedReader br = new BufferedReader(fr);
			String sCurrentLine;
			
			int count=0;
			try {
				this.users_file=new int[this.execution_no];
				while ((sCurrentLine = br.readLine()) != null) {
					try{
					this.users_file[count]=Integer.parseInt(sCurrentLine);
					}
					catch(NumberFormatException e){
						e.printStackTrace();
					}
					
					count++;
				}}
				catch (IOException e) {

					e.printStackTrace();

				}
		}
				
			catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
}
		
		
		
		
		
		
	}
	
	
	

