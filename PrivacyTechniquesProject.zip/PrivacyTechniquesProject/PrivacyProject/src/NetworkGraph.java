import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class NetworkGraph extends FileOperation {
 
   
	public int [][] network_array;
 public NetworkGraph(String filename, int userno) {
		super(filename, userno);
		
	}
 public NetworkGraph(String filename){
	 super(filename);
	 
	 
	 
 }


	public void create(){
		
		int [][] graph_matrix=new int[this.user_no][this.user_no];
		int [] line=new int[this.user_no];
		int count=0;
		int l=0;
		Random rl=new Random();
		for(int i=0;i<this.user_no;i++){
			for(int j=0;j<this.user_no;j++){
				if(i==j){
					graph_matrix[i][j]=0;}
				else{
					graph_matrix[i][j]=-1;
				}
			}
			line[i]=-1;
		}
		
		
		 try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(this.filename));
			
			
			
			
			
			for(int i=0;i<this.user_no;i++){
				for(int j=0;j<this.user_no;j++){
					if(i!=j){
						if(graph_matrix[j][i]!=-1){
							graph_matrix[i][j]=graph_matrix[j][i];
						}
						else{
							graph_matrix[i][j]=NetworkGraph.link();
						}
					}
					/*
					line[j]=graph_matrix[i][j];
					
					//writer.write(String.valueOf(graph_matrix[i][j]));
					if(j==this.user_no-1){
						
						
						for(int k=0;k<this.user_no;k++){
							if(line[k]!=0){
								
								count=1;
								break;
							}
						}
						
						if(count==0){
							l=i;
							while(l==i){
							l=rl.nextInt(this.user_no);
							}
							graph_matrix[i][l]=1;
							graph_matrix[l][i]=1;
							
						}
						count=0;
						for(int k=0;k<this.user_no;k++){
							line[k]=-1;
						}
						
					}*/
				}
			}
			for(int i=0;i<this.user_no;i++){
				for(int j=0;j<this.user_no;j++){
					//System.out.print(graph_matrix[i][j]);
					writer.write(String.valueOf(graph_matrix[i][j]));
					if(j!=this.user_no-1){
						//System.out.print(" ");
						writer.write(" ");}}
				if(i!=this.user_no-1){
					writer.newLine();
				//System.out.println("");
					}
			}
			
			writer.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public void read(){
		
		try {
			FileReader fr = new FileReader(this.filename);
			BufferedReader br = new BufferedReader(fr);
			String sCurrentLine;
			String[] line=new String[this.user_no];
			int count=0;
			try {
				this.network_array=new int[this.user_no][this.user_no];
				while ((sCurrentLine = br.readLine()) != null) {
					line=sCurrentLine.split(" ");
					for(int i=0;i<this.user_no;i++){
						this.network_array[count][i]=Integer.parseInt(line[i]);
					}
					
					count++;
					
				}
				
				
		}
			catch (IOException e) {

				e.printStackTrace();

			}
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
	
	private static int link(){
		int con;
		
		Random r=new Random();
		con=r.nextInt(2);
		
		
		return con;
		
		
	}
	

}