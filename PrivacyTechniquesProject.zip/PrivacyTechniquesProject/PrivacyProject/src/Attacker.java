import java.awt.Point;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;


public class Attacker {
	private String filename;
	private int [][]  graph;
	private double []  prob;
	private int corrupted_users;
	private  int counter=0;
	public ArrayList<Integer> guess_sender;
	public Attacker(String f, int [][]g,double[] p,int c){
		this.filename=f;
		this.graph=g;
		this.prob=p;
		this.corrupted_users=c;
		this.guess_sender=new ArrayList<Integer>();
	}
	public void setinfo(String f){
		this.filename=f;
	}
	
	public int get_max_prob(){
		int id=0;
		double max=this.prob[0];
		int n=this.prob.length;
		ArrayList<Integer> maxids=new ArrayList<Integer>();
		//int n=this.prob.length-this.corrupted_users;
		for(int i=1;i<n;i++){
			if(this.prob[i]>max){
				max=this.prob[i];
			}
		}
		//get random from the max
		Random randomno = new Random();
		for(int i=0;i<n;i++){
			if(this.prob[i]==max){
				maxids.add(i);
			}
		}
		
		int index=randomno.nextInt(maxids.size());
		
		id=maxids.get(index);
		return id;
	}
	
	
	public int add(int a,int b){
		int c=0;
		if((a==1 || a==0) && (b==0||b==1)){
			c=a+b;
			if(c==2){
				c=0;
			}
		}
		else{
			c=-1;
		}
		return c;
	}
	
	public  double honest_cum(){
		double k=0.00;
		//int n=this.prob.length-this.corrupted_users;
		int n=this.prob.length;
		for(int i=0;i<n;i++){
			k=k+this.prob[i];
		}
		return k;
	}
	
	/*
	public  double honest_cum(int w){
		double k=0.00;
		int n=this.prob.length-this.corrupted_users;
		for(int i=0;i<n;i++){
			
			if(w==i)
				continue;
			k=k+this.prob[i];
			//System.out.println(k);
		}
		return k;
	}*/
	
	
	
	
	public int  get_ex_number(){
		int count=0;
		try {
			FileReader fr = new FileReader(this.filename);
			BufferedReader br = new BufferedReader(fr);
			String sCurrentLine;
			try {
				
				while ((sCurrentLine = br.readLine()) != null) {
					count++;
					
				}
				
				
		}
			catch (IOException e) {

				e.printStackTrace();

			}
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return count;
	}
	public void  crowds_attack(int k,int m){
		int guess=-1;
		int count=0;
		double pf=0.75;
		//with corrupted users
		
		try {
			FileReader fr = new FileReader(this.filename);
			BufferedReader br = new BufferedReader(fr);
			String sCurrentLine;
			
			
			
			
			try {
				while ((sCurrentLine = br.readLine()) != null) {
					if(count==k){
						break;
					}
					count++;}
				//seperate nodes 
				String []nodes_line=sCurrentLine.split(" ");
				//separate corrupted nodes and detected noded
				String [] values;
				String [] temp=new String[2];
				//count of honest users
				
				HashMap<Integer,ArrayList<Integer>> adv_info=new HashMap<Integer,ArrayList<Integer>>();
				ArrayList<Integer> nodes_detected=new ArrayList<Integer>();
				for(int i=0;i<nodes_line.length;i++){
					//System.out.println(nodes_line[i]);
					temp=(nodes_line[i]).split(":");
					/*for(int j=0;j<temp.length;j++){
						System.out.println(temp[j]);
					}*/
					values=temp[1].split(",");
					for(int n=0;n<values.length;n++){
						nodes_detected.add(Integer.parseInt(values[n]));
						//System.out.println(values[n]);
					}
					
					adv_info.put(Integer.parseInt(temp[0]), nodes_detected);
					
					nodes_detected=new ArrayList<Integer>();
					
					
				} 
				
				int key,x;
				boolean c_link=true;
				boolean no_link=true;
				//int c=this.prob.length-this.corrupted_users;
				int c=this.prob.length;
				int no_users=c+this.corrupted_users;
				//with corrupted users
				if(this.corrupted_users!=0){
					ArrayList<Integer> detnodes=new ArrayList<Integer>();
				for (Entry<Integer, ArrayList<Integer>> entry : adv_info.entrySet()) {
					//special cases
					
					key=(entry.getKey()).intValue();
					
					
					System.out.println("corrupted node:"+key+":");
					nodes_detected=entry.getValue();
					
						for(int i=0;i<nodes_detected.size();i++){
							x=nodes_detected.get(i);
							if(x<c){
							detnodes.add(x);}
							System.out.print(x);
							if(i!=nodes_detected.size()-1)
								System.out.print("|");
							if(x==-1 && key>=c){
								guess=key;
								break;
							}
							else{
								if(key==-1 && x<c){
									for(int l=0;l<no_users;l++){
										if(this.graph[x][l]==1){
											no_link=false;
											break;
										}
									}
									if(no_link==true){
										guess=x;
									}
								}
							
							}
							
							
							
						
					}
					
						System.out.println("");
						
				}		
					if(guess==-1){
						//constant probabilities
						int c1=this.corrupted_users;
						int m1= no_users;
						double b=(c1*(m1-pf*(c-1)))/(m1*(m1-pf*c));//probability deti|useri
						double c2=(double)(b)- (double)(c1)/(double)(m1);//probability deti |userj
						double a=(double)(1-b-(c-1)*c2);//probability no detection|useri
						System.out.println("a: "+a);
						System.out.println("b: "+b);
						System.out.println("c: "+c2);
						
						
						
						
						if(adv_info.size()==1){
							//?
							/*double h=this.honest_cum();
							double p_none=a*h;//probability no detection
							System.out.println("pn:"+p_none);
							System.out.println("h:"+h);
							double [] pg=new double[c];//probabilty useri|no detection
							double maxp=pg[0];
							for(int i=0;i<c;i++){
								
								pg[i]=(a*this.prob[i])/p_none;
								if(maxp<pg[i]){
									maxp=pg[i];
									guess=i;
								}
								System.out.println(i+":"+pg[i]);
							}
							*/
							guess=m;
						}
						else{
							double [] pd=new double[c];//probability deti
							double sumd=0;
							double pu=0;
							double h=this.honest_cum();
							for(int i=0;i<c;i++){
								pu=this.prob[i];
								sumd=h-pu;
								pd[i]=b*pu+c2*sumd;
								//System.out.println("pd:"+pd[i]);
								sumd=0;
							
							
						}
						Set<Integer> unique_nodes = new TreeSet<Integer>(detnodes);	
						int detnum=unique_nodes.size();
						//System.out.println(unique_nodes);
						//System.out.println(detnum);
						Iterator<Integer> itr = unique_nodes.iterator();
						double [][]  pdu=new double[c][detnum];
						int id;
						int cn=0;
						while(itr.hasNext()){
							id=itr.next();
							for(int i=0;i<c;i++){
								if(i==id){
									pdu[i][cn]=(b*this.prob[i])/pd[i];}//probability useri|deti
								else{
									pdu[i][cn]=(c2*this.prob[i])/pd[id];//probability useri|detj
								}
							}
							cn=cn+1;
						}
						double [] final_prob=new double[c];
						for(int i=0;i<c;i++){
							final_prob[i]=this.prob[i];
						}
						//double sum=0.0;
						double max=0.0;
						for(int i=0;i<c;i++){
							for(int j=0;j<detnum;j++){
								final_prob[i]=final_prob[i]*pdu[i][j];
								
							}
						}
						for(int i=0;i<c;i++){
							if(max<final_prob[i]){
								max=final_prob[i];
								guess=i;
							}
							
						}
							/*for(int j=0;j<detnum;j++){
								for(int i=0;i<c;i++){
									System.out.print(pdu[i][j]+" ");
									sum+=pdu[i][j];
							}
							System.out.println(sum);	
							System.out.println("");
							sum=0;
						}
						*/
						
						
						
						
							
					}
				}}
				else{
					ArrayList<Integer> s1=adv_info.get(-1);
					int s0=s1.get(0);
					no_link=true;
					for(int q=0;q<no_users;q++){
						if(this.graph[s0][q]==1){
							no_link=false;
					}
					}
					if(no_link==true){
						guess=s0;
					}
					else{
					guess=m;
					}
				}
				 String dir = (System.getProperty("user.dir")+"/files/");
				//String dir = (System.getProperty("user.dir")+"\\src\\files\\");
				String filename=dir+"guess.txt";	
				File file = new File(filename);
				boolean exist=false;
					if(file.exists()){
						
						exist=true;
					}
					 try {
						 BufferedWriter writer;
						 if(exist && this.counter>0){
							 writer = new BufferedWriter(new FileWriter(filename,exist));
							}else{
								 writer = new BufferedWriter(new FileWriter(filename));
							}
						 writer.write(String.valueOf(guess));
						 System.out.println("sender is "+guess);
						 this.guess_sender.add(guess);
						 writer.newLine();
						 writer.close();
							
					 }
					 catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					
					
					
					
					
				
				this.counter++;
				
				
				
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
		//find execution info
		
			
		
		
		
	
	
	public  void dcattack(int k,int m){
		int count=0;
		int guess=m;
		int no_users=this.prob.length+this.corrupted_users;
		//System.out.println("a"+guess);
		boolean wt=true;
		//System.out.println("a1");
		try {
			FileReader fr = new FileReader(this.filename);
			BufferedReader br = new BufferedReader(fr);
			String sCurrentLine;
			//find execution info
			//System.out.println("a2");
			try {
				
				while ((sCurrentLine = br.readLine()) != null) {
					if(count==k){
						break;
					}
					count++;
					
				}
				//separate data in dc
				String[] line;
				line=sCurrentLine.split(" ");
				int [] output=new int[no_users];
				for(int i=0; i<no_users;i++){
					output[i]=Integer.parseInt(line[i]);
				}
				for(int i=0; i<no_users;i++){
					System.out.println("output"+i+":"+output[i]);
					
					
				}
				
				
				//System.out.println("a3");
				int c=this.prob.length;
				boolean nolink=true;
				boolean corrupt_link=true;
				ArrayList<Integer> candidates=new ArrayList<Integer> ();
				for(int i=0;i<c;i++){
					for(int j=0;j<no_users;j++){
						if(this.graph[i][j]==1){
							nolink=false;
							if(j<c){
								corrupt_link=false;
								//System.out.println("0node"+i);
							break;}
						}
					}
					if(nolink==true && output[i]==1){
						guess=i;
						//System.out.println("case1");
						break;
					}
					if(corrupt_link==true){
						candidates.add(i);
						//System.out.println("1node"+i);
						//System.out.println("b"+i);
					}
					
					
					corrupt_link=true;
					nolink=true;
					
				}
				
			//	System.out.println("a4");
				if(guess==m){
				
				HashMap<Point,Integer> known_coins=new HashMap<Point,Integer>();
				
				//int pos=this.prob.length;
				int pos=no_users;
				int sum=0;
				for(int i=c;i<no_users;i++){
					for(int j=0;j<no_users;j++){
						if(i!=j){
							if(this.graph[i][j]==1){
								known_coins.put(new Point(i,j), Integer.parseInt(line[pos]));
								//System.out.println(i+" "+j+" "+pos +" "+line[pos]);
								sum=this.add(sum,Integer.parseInt(line[pos]));
								pos=pos+1;
							}
						}
						
						
						if(pos==line.length){
							break;
						}
						
						
					}
					/*if(pos==line.length-1){
						break;
					}*/
					//System.out.println(i+" "+sum);
					if(sum!=output[i]){
						guess=i;
						//System.out.println("case2");
						break;
					}
					sum=0;
				}
				int x,y,value;
				sum=0;
				
				
				
				//System.out.println(guess);
				
				//System.out.println("a5");
				if(guess==m){
				for(int i=0;i<candidates.size();i++){
					for (Map.Entry<Point, Integer> entry : known_coins.entrySet()) {
							x=(entry.getKey()).x;
							y=(entry.getKey()).y;
							value=(entry.getValue()).intValue();
							System.out.println("("+x+","+y+"): "+value);
							if(y==(candidates.get(i))){
								sum=this.add(sum,value);
							}
							
					}
					if(sum!=output[candidates.get(i)]){
						guess=candidates.get(i);
						//System.out.println("case3");
						wt=false;
						break;
					}
					sum=0;
				}
				}
				
				
				
				
				}
				//System.out.println("a6");
			String dir = (System.getProperty("user.dir")+"/files/");
			//String dir = (System.getProperty("user.dir")+"\\src\\files\\");
			String filename=dir+"guess.txt";	
				
			File file = new File(filename);
			boolean exist=false;
				if(file.exists()){
					
					exist=true;
				}
				 try {
					 BufferedWriter writer;
					 if(exist && this.counter>0){
						 writer = new BufferedWriter(new FileWriter(filename,exist));
						}else{
							 writer = new BufferedWriter(new FileWriter(filename));
						}
					 writer.write(String.valueOf(guess));
					 System.out.println("sender is "+guess);
					 this.guess_sender.add(guess);
					 writer.newLine();
					 writer.close();
						
				 }
				 catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
				
				
				
				
			
			this.counter++;
			//System.out.println(wt);
			
		}
			catch (IOException e) {

				e.printStackTrace();

			}
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		
	}

	 
	
	
	
	
}
